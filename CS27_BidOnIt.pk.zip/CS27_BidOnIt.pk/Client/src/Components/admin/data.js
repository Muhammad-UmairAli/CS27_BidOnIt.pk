export const Sellers= [
    { "id": "1", "name": "Wasif", "Phone": "92320333344", "email": "wasif@email.com" },
    { "id": "2", "name": "Saad", "Phone": "92321233344", "email": "saad@email.com" },
    { "id": "3", "name": "Ali", "Phone": "92320222244", "email": "ali@email.com" },
    { "id": "4", "name": "Afnan", "Phone": "92320445444", "email": "afnan@email.com" }
 ]
export const Users=[
{ "id": "1", "name": "Wasif", "Phone": "92320333344", "email": "wasif@email.com" },
    { "id": "2", "name": "Saad", "Phone": "92321233344", "email": "saad@email.com" },
    { "id": "3", "name": "Ali", "Phone": "92320222244", "email": "ali@email.com" },
    { "id": "4", "name": "Afnan", "Phone": "92320445444", "email": "afnan@email.com" }

]

export const orders=[

{ "id": "1", "pname": "Mobile", "Phone": "92320333344", "bid":"200", "email": "wasif@email.com" },
    { "id": "2", "pname": "Laptop", "Phone": "92321233344", "bid":"200","email": "saad@email.com" },
    { "id": "3", "pname": "Cushions", "Phone": "92320222244","bid":"200", "email": "ali@email.com" },
    { "id": "4", "pname": "Ball", "Phone": "92320445444", "bid":"200","email": "afnan@email.com" }
]